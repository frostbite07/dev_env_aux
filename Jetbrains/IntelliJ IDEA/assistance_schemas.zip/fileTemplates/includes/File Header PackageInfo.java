// -- FILE ------------------------------------------------------------------
// name       : ${NAME}.java
// project    : #parse("project.EOL.txt")
// created    : #parse("author.txt") - ${YEAR}-${MONTH}-${DAY}
// language   : java package meta data and documentation
// environment: JDK #parse("JDK.EOL.txt")
// copyright  : (c) 2008-${YEAR} by #parse("copyright-owner.EOL.txt")
// license    : #parse("license.EOL.txt")
// --------------------------------------------------------------------------
