#parse("File Header.java")
#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end



// -- INTERFACE -------------------------------------------------------------
/** TODO: brief description of the interface.
@author   #parse("author.EOL.txt")
@since    #parse("version.EOL.txt")
*///-------------------------------------------------------------------------
public interface ${NAME} {


// -- METHOD ----------------------------------------------------------------
/** TODO: method javadoc..
@since    #parse("version.EOL.txt")
*///-------------------------------------------------------------------------
public void someMethod(); // TODO: replace with proper method


} // interface ${NAME}
// --------------------------------------------------------------------------
#include("EOF.java")
