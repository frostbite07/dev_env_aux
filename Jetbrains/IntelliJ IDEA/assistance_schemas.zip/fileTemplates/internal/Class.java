#parse("File Header.java")
#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end



// -- CLASS -----------------------------------------------------------------
/** TODO: brief description of the class.
@author   #parse("author.EOL.txt")
@since    #parse("version.EOL.txt")
*///-------------------------------------------------------------------------
public class ${NAME} {


// -- METHOD ----------------------------------------------------------------
/** Creates a new instance.
@since    #parse("version.EOL.txt")
*///-------------------------------------------------------------------------
public ${NAME}()
{
} // ${NAME}


} // class ${NAME}
// --------------------------------------------------------------------------
#include("EOF.java")
