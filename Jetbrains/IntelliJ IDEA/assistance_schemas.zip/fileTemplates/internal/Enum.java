#parse("File Header.java")
#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end



// -- CLASS -----------------------------------------------------------------
/** TODO: brief description of the enum.
@author   #parse("author.EOL.txt")
@since    #parse("version.EOL.txt")
*///-------------------------------------------------------------------------
public enum ${NAME} {


/** TODO: description of value 1 */
VALUE_1,
/** TODO: description of value 2 */
VALUE_2,
/** TODO: description of value 3 */
VALUE_3;


} // enum ${NAME}
// --------------------------------------------------------------------------
#include("EOF.java")
