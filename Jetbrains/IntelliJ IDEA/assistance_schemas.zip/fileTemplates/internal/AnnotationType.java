#parse("File Header.java")
#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end



// -- CLASS -----------------------------------------------------------------
/** TODO: brief description of the annotation.
@author   #parse("author.EOL.txt")
@since    #parse("version.EOL.txt")
*///-------------------------------------------------------------------------
public @interface ${NAME} {

} // @interface ${NAME}
// --------------------------------------------------------------------------
#include("EOF.java")
