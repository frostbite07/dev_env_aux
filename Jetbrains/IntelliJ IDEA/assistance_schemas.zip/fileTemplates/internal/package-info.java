#parse("File Header PackageInfo.java")


// -- PACKAGE ---------------------------------------------------------------
/** <b>TODO: brief description of the package purpose</b>.<br>
@author   #parse("author.EOL.txt")
@since    #parse("version.EOL.txt")
*///-------------------------------------------------------------------------
package ${PACKAGE_NAME};
#include("EOF.java")
