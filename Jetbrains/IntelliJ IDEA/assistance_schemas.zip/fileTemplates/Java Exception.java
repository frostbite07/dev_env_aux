#parse("File Header.java")
#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end



// -- CLASS -----------------------------------------------------------------
/** TODO: brief description of the exception.
@author   #parse("author.EOL.txt")
@since    #parse("version.EOL.txt")
*///-------------------------------------------------------------------------
public class ${NAME} extends Exception {


// -- METHOD ----------------------------------------------------------------
/** Creates a new instance without message.
@since    #parse("version.EOL.txt")
*///-------------------------------------------------------------------------
public ${NAME}()
{
} // ${NAME}


// -- METHOD ----------------------------------------------------------------
/** Creates a new instance with the given message.
@since    #parse("version.EOL.txt")
@param    pMessage the message passed on to the super class
*///-------------------------------------------------------------------------
public ${NAME}(
  final String pMessage
)
{
  super( pMessage );
} // ${NAME}


// -- METHOD ----------------------------------------------------------------
/** Creates a new instance without message and with the given causing throwable.
@since    #parse("version.EOL.txt")
@param    pCause the original error causing this one
*///-------------------------------------------------------------------------
public ${NAME}(
  final Throwable pCause
)
{
  super( pCause );
} // ${NAME}


// -- METHOD ----------------------------------------------------------------
/** Creates a new instance with the given message and causing throwable.
@since    #parse("version.EOL.txt")
@param    pMessage the error message
@param    pCause the original error causing this one
*///-------------------------------------------------------------------------
public ${NAME}(
  final String    pMessage,
  final Throwable pCause
)
{
  super( pMessage, pCause );
} // ${NAME}


// ----- members -----
/** serialization versioning: necessary to prevent obfuscation from breaking it */
private static final long serialVersionUID = 0x1L;


} // class ${NAME}
// --------------------------------------------------------------------------
#include("EOF.java")
