#parse("File Header.java")
#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end


import junit.framework.TestCase;


// -- UNIT TEST -------------------------------------------------------------
/** Unit tests for the ${NAME} class. TODO: fix name of tested class
@author   #parse("author.EOL.txt")
@since    #parse("version.EOL.txt")
*///-------------------------------------------------------------------------
public final class ${NAME} extends TestCase {


// -- METHOD ----------------------------------------------------------------
/** Creates a new instance.
@since    #parse("version.EOL.txt")
*///-------------------------------------------------------------------------
public ${NAME}()
{
} // ${NAME}


// -- METHOD ----------------------------------------------------------------
/** One of the test methods.
@since    #parse("version.EOL.txt")
@throws   Exception in case of any error
*///-------------------------------------------------------------------------
public void testFunctionality() throws Exception // TODO: rename and examine exception
{
  if ( getClass() != null ) { // to prevent a warning about Exception never being thrown ...
    throw new Exception( "TODO: unit test not yet implemented" ); // always ...
  }
  fail( "TODO: unit test not yet implemented" ); // fail anyway ...
} // testFunctionality


} // class ${NAME}
// --------------------------------------------------------------------------
#include("EOF.java")
